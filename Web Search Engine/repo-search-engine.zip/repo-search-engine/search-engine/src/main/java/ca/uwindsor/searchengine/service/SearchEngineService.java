package ca.uwindsor.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.uwindsor.searchengine.bean.Word;
import ca.uwindsor.searchengine.util.TST;
import ca.uwindsor.searchengine.view.OccurrenceView;

@Service
@SuppressWarnings("unused")
public class SearchEngineService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${search.root.page}")
    private String rootPage;

    @Value("${search.tst.show}")
    private int tstShow;

    private TST<Word> tst;

    private WordService wordService;
    private WebPageService webPageService;

    @Autowired
    SearchEngineService(WordService wordService,
                        WebPageService webPageService) {
        this.wordService = wordService;
        this.webPageService = webPageService;
    }

    public List<OccurrenceView> search(String word) {
        return Optional.ofNullable(this.tst.get(StringUtils.lowerCase(word)))
                       .map(w -> w.getOccurrences().stream()
                                   .sorted()
                                   .map(o -> new OccurrenceView(o.getOccurrences(),
                                                                o.getWebPage().getUrl(),
                                                                o.getShow()))
                                   .collect(Collectors.toList()))
                       .orElse(new ArrayList<>());
    }

    @PostConstruct
    private void loadSearchEngineData() throws IOException{
        this.logger.info("Loading Data... Using '{}' as root page.",this.rootPage);
        this.tst = this.wordService.generateWords(this.webPageService.generateWebPages());
        this.showTST();
        this.logger.info("Data Loaded Successfully!!!");

    }

    private void showTST() {
        this.tst.keys().forEach(k -> {
               if(this.tst.get(k).getOccurrences().size()>this.tstShow){
                  this.logger.debug("{} - {}",k,this.tst.get(k).getOccurrences().size());
               }});
    }
}
