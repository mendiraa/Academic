package ca.uwindsor.searchengine.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.uwindsor.searchengine.bean.Occurrence;
import ca.uwindsor.searchengine.bean.WebPage;
import ca.uwindsor.searchengine.bean.Word;
import ca.uwindsor.searchengine.util.Decorator;
import ca.uwindsor.searchengine.util.TST;

@Service
public class WordService {

    @Value("${search.occurrence.show}")
    private int showSize;

    TST<Word> generateWords(List<WebPage> webPages){
        TST<Word> tst = new TST<Word>();
        webPages.stream()
                .map(this::generateWords)
                .flatMap(List::stream)
                .forEach(w -> this.addToTST(tst,w));
        return tst;
    }

    private void addToTST(TST<Word> tst, Word word) {
        if (tst.contains(word.getName())) {
            tst.get(word.getName()).addOcurrence(word);
        } else {
            tst.put(word.getName(), word);
        }
    }

    private List<Word> generateWords(WebPage webPage) {
        List<Word> words = new ArrayList<>();
        Arrays.stream(webPage.getText().split(" "))
              .filter(StringUtils::isNotBlank)
              .map(StringUtils::lowerCase)
              .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
              .forEach((k,v)-> words.add(new Word(k,this.generateOccurence(k,v,webPage))));
        return words;
    }

    private Occurrence generateOccurence(String word, long occurences, WebPage webPage) {
        return new Occurrence(occurences,this.generateShow(word,webPage),webPage);
    }

    private String generateShow(String word, WebPage webPage) {
         int index = StringUtils.indexOf(StringUtils.lowerCase(webPage.getText()),
                                         StringUtils.lowerCase(word));
         String str = "";
         if (index<showSize/2) {
             str = StringUtils.substring(webPage.getText(),0,showSize);
         } else {
             if ((webPage.getText().length()-index)<showSize/2) {
                 str = StringUtils.substring(webPage.getText(),webPage.getText().length()-showSize);
             } else {
                 str = StringUtils.substring(webPage.getText(),index-showSize/2,index+showSize/2);
             }
         }
         return Decorator.decorate(str,word);
    }
}
