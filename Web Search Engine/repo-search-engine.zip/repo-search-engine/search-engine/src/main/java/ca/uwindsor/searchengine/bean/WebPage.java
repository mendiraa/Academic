package ca.uwindsor.searchengine.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WebPage {

    private String url;
    private String text;
    private String html;
}
