package ca.uwindsor.searchengine.constant;

public class RegexConstant {
    public static final String REGEX_WEB_URL = "((?:https?://|www\\d{0,3}[.]|[a-z0-9.\\-]+[.][a-z]{2,4}/)(?:[^\\s()<>]+|"
                                         + "\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\))+(?:\\(([^\\s()<>]+|(\\([^\\s()<>]+"
                                         + "\\)))*\\)|[^\\s`!()\\[\\]{};:'\".,<>?������]))";
}
