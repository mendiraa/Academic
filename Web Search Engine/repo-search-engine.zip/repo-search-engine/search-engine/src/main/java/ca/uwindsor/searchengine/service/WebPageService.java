package ca.uwindsor.searchengine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.uwindsor.searchengine.bean.WebPage;
import ca.uwindsor.searchengine.constant.RegexConstant;

@Service
public class WebPageService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${search.root.page}")
    private String rootPage;

    List<WebPage> generateWebPages() throws IOException{
        return this.retrieveWebURLs(Jsoup.connect(this.rootPage).get().html()).stream()
                         .filter(this::notWebPage)
                         .distinct()
                         .map(this::generateWebPage)
                         .filter(Optional::isPresent)
                         .map(Optional::get)
                         .collect(Collectors.toList());
    }

    private List<String> retrieveWebURLs(String hmtl){
        Matcher matcher = Pattern.compile(RegexConstant.REGEX_WEB_URL, Pattern.CASE_INSENSITIVE)
                                 .matcher(hmtl);

        List<String> urls = new ArrayList<>();
        while (matcher.find()) {
            urls.add(matcher.group());
        }
        return urls;
    }

    private boolean notWebPage(String str) {
        return Optional.of(str)
                .filter(s -> !s.contains(".js"))
                .filter(s -> !s.contains(".jpg"))
                .filter(s -> !s.contains(".png"))
                .filter(s -> !s.contains(".svg"))
                .filter(s -> !s.contains(".swf"))
                .filter(s -> !s.contains(".css"))
                .filter(s -> !s.contains(".ico"))
                .filter(s -> !s.contains(".dtd"))
                .isPresent();
    }

    private Optional<WebPage> generateWebPage(String url) {
        Optional<WebPage> optional= Optional.empty();
        try {
            Document doc = Jsoup.connect(url).get();
            optional = Optional.of(new WebPage(url,doc.text(),doc.html()));
            logger.debug("URL Loaded!!!  {}",url);
        } catch (Exception ex) {
            logger.error("Error while loading URL: {}; Message:{}",url,ex.getMessage());
        }
        return optional;
    }
}
