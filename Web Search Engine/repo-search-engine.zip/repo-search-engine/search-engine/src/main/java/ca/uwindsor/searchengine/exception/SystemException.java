package ca.uwindsor.searchengine.exception;

public class SystemException extends RuntimeException {

    private static final long serialVersionUID = -1999224253910608865L;

    public SystemException(String message) {
        super(message);
    }
}
