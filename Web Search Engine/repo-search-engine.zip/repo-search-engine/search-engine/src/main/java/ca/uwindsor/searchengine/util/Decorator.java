package ca.uwindsor.searchengine.util;

import org.apache.commons.lang3.StringUtils;

public class Decorator {

    public static String decorate(String text, String word) {

        text = Decorator.decorateWord(text, word);
        text = Decorator.decorateCapital(text, word);
        return String.format(". . .%s. . .",text);
    }

    public static String decorateCapital(String text, String word) {
        return StringUtils.replace(text,
                                   String.format(" %s ",StringUtils.capitalize(word)),
                                   String.format(" <span style='background-color:yellow'>%s</span> ",StringUtils.capitalize(word)));
    }

    public static String decorateWord(String text, String word) {
        return StringUtils.replace(text,
                String.format(" %s ",word),
                String.format(" <span style='background-color:yellow'>%s</span> ",word));
    }
}
