package ca.uwindsor.searchengine.view;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OccurrenceView {

    private long occurrences;
    private String url;
    private String show;
}
