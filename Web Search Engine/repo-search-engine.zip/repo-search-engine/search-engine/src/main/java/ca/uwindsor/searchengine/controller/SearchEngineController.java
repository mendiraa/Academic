package ca.uwindsor.searchengine.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ca.uwindsor.searchengine.service.SearchEngineService;

@Controller
public class SearchEngineController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    SearchEngineService searchEngineService;

    @Autowired
    public SearchEngineController(SearchEngineService searchEngineService) {
        this.searchEngineService = searchEngineService;
    }

    @PostMapping("/search")
    ModelAndView search(@RequestParam("word") String word) {
        logger.debug("(POST) /search : ({})", word);
        return new ModelAndView("index","occurrences",this.searchEngineService.search(word));
    }
}
