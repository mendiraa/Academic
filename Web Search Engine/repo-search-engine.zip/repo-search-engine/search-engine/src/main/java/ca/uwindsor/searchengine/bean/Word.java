package ca.uwindsor.searchengine.bean;

import java.util.ArrayList;
import java.util.List;

import ca.uwindsor.searchengine.exception.SystemException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Word {

    private String name;
    private List<Occurrence> occurrences;

    public Word(String name, Occurrence ocurrence) {
        super();

        this.name = name;
        this.occurrences = new ArrayList<>();

        this.occurrences.add(ocurrence);
    }

    public void addOcurrence(Word word) {
        if (!this.name.equals(word.getName())) {
            throw new
            SystemException(String.format("Cannot add word '%s' to word %s'!!!",word.getName(),this.name));
        } else {
            this.occurrences.add(word.occurrences.get(0));
        }
    }
}
