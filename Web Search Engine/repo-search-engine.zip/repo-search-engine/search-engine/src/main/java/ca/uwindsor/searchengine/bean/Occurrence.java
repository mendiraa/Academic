package ca.uwindsor.searchengine.bean;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Occurrence implements Comparable<Occurrence>{

    private long occurrences;

    private String show;

    private List<Integer> offsets;

    private WebPage webPage;

    public Occurrence(long occurrences, String show, WebPage webPage) {
        super();
        this.occurrences = occurrences;
        this.show = show;
        this.webPage = webPage;
    }

    @Override
    public int compareTo(Occurrence occurrence) {
        return (int)(occurrence.getOccurrences() - this.getOccurrences());
    }
}
