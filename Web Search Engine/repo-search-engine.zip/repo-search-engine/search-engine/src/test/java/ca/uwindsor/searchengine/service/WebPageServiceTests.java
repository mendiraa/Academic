package ca.uwindsor.searchengine.service;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import ca.uwindsor.searchengine.bean.WebPage;

import org.assertj.core.api.Assertions;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class WebPageServiceTests {

    @Autowired
    WebPageService webPageService;

    @Test
    public void validateWebPages() throws IOException {
//        List<WebPage> webPages = this.webPageService.generateWebPages();
//
//        Assertions.assertThat(webPages)
//                  .isNotNull()
//                  .size()
//                  .isGreaterThanOrEqualTo(70);
//        Assertions.assertThat(webPages)
//                  .extracting("text",String.class)
//                  .extracting("length",Integer.class).
//                  .isGreaterThanOrEqualTo(100);
    }

}
